import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subscription, Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class KataForFunService {
  
   constructor(private http: HttpClient) {}
   
   convertNumber(inputNumber: number): Observable<String> {
    return this.http.get<String>(`http://localhost:8080/kata-for-fun/${inputNumber}`);
   }
  

}
