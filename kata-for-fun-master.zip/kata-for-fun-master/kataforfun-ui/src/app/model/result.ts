export class Result{
    result: string;
}