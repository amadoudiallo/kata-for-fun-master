export interface ItemWithPath{
    text: string;
    path: string;
}
