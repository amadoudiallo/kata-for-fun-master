import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription, Observable} from 'rxjs';
import { KataForFunService } from '../kata-for-fun.service';

@Component({
  selector: 'app-kata-for-fun',
  templateUrl: './kata-for-fun.component.html'
})
export class KataForFunComponent implements OnInit, OnDestroy {

 
  convertedDtoSet = new Set<NumberConverted>();
   
  constructor(private kataForFunService: KataForFunService) { }

  ngOnInit(): void {
 
  }

  ngOnDestroy(): void {
  }

  convertNumber(inputNumber: number): void {
	this.kataForFunService.convertNumber(inputNumber).subscribe((res: String) => {     
    let convertedDto = {numberToConvert:inputNumber,result:res} as  NumberConverted;
	this.convertedDtoSet.add(convertedDto);
	//console.log(convertedDto.numberToConvert);
	//console.log(convertedDto.result);	 
    });	
  }

}

interface NumberConverted {
  numberToConvert: number;
  result: string;
}
