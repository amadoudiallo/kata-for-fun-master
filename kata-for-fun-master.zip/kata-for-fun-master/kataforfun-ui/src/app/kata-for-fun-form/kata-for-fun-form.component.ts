import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { KataForFunService } from '../kata-for-fun.service';
import { Subscription, Observable} from 'rxjs';
import { map, tap } from 'rxjs/operators';


@Component({
  selector: 'app-kata-for-fun-form',
  templateUrl: './kata-for-fun-form.component.html'
})
export class KataForFunFormComponent implements OnInit {
  inputNumberForm!: FormGroup;
  
  inputNumber!: string ;
  
  @Output() submitNumberOutput= new EventEmitter();
  
  constructor(private formBuilder: FormBuilder) {  
  }

  ngOnInit(): void {
	this.inputNumberForm = this.formBuilder.group({
	inputNumber:"",
	});
   
  }

  submitNumber(): void {
    if(!isNaN(this.inputNumberForm.value.inputNumber)){	
		this.submitNumberOutput.emit(parseInt(this.inputNumberForm.value.inputNumber));
	}
  }  

}
