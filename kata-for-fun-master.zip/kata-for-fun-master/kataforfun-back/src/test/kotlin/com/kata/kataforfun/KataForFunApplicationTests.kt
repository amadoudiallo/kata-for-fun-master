package com.kata.kataforfun

import com.kata.kataforfun.services.KataForFunService
import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest


@SpringBootTest
class KataForFunApplicationTests {

	@Test
    fun contextLoads() {
    }
	
	@Test
    fun convertNumberTest() {
	
		var x = 3
		var res = KataForFunService().convertNumber(x)
    }
}
