package com.kata.kataforfun.services

import org.springframework.stereotype.Component

@Component
class KataForFunService {

    fun convertNumber(inputNumber: Int): String {
	    var retval = ""
		if(	inputNumber != null){   
			val inputString = inputNumber.toString()
			var x = inputNumber
			
			while (x  > 1) {			    
				if( x % 10  == 3){
					retval = "Kata" + retval
				}else if( x % 10 == 5){
					retval =  "For" + retval
				}else if( x % 10 == 7){
					retval =  "Fun" + retval
				}
				x = x / 10 
			}
			
			if( inputNumber % 5 == 0){
				retval =  "For" +retval 
			}
			
			if( inputNumber % 3  == 0){
				retval =  "Kata" + retval 
			}			
		 			
			if(retval.length == 0){
				retval = inputString
			}       
		}
		return retval		
    }

}